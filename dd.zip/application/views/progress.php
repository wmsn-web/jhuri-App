<?php include("fnc.php"); ?>
<!DOCTYPE html>
<html>
<head>
	<!----==========Layout===========--------->
	<?php include("inc/layout.php"); ?>
</head>
<body>
<div class="container">
	<div class="progressd">
		<div class="vertical_bar">
			<div class="success_bar">
				
			</div>
		</div>
		<ul class="steps">
			<li class="greens"><i class="fas fa-check-circle"></i> Verify</li>
			<li><i class="fas fa-check-circle"></i> Confirmed</li>
			<li><i class="fas fa-check-circle"></i> On Process</li>
			<li><i class="fas fa-check-circle"></i> Price</li>
			<li><i class="fas fa-check-circle"></i> Received</li>
		</ul>
    </div>
</div>

<?php include("inc/js.php"); ?>
</body>
</html>