<div class="fx_btm">
		<div class="footMenu">
			<ul>
				<li>
					<a href="<?= base_url(); ?>">
						<i class="fas fa-home"></i>
					</a>
				</li>
				<li>
					<a id="btmTgl" href="javascript:void(0)">
						<i id="btmBar" class="fas fa-bars"></i>
					</a>
				</li>
				<li>
					<a id="adOrd" href="javascript:void(0)">
						<i id="btmPls" class="fas fa-plus-circle"></i>
					</a>
				</li>
				<li>
					<a id="mOrd" href="javascript:void(0)">
						<i class="fas fa-shopping-cart"></i>
					</a>
				</li>
			</ul>
		</div>
	</div>
	<?php include("cat_menu.php"); ?>
	<?php include("addord.php"); ?>
	<div class="myOrder">
		<div class="container-fluid">
			<div class="row">
				<div class="navicon cl1 bkbtn">
					<img style="width: 25px" src="<?= base_url(); ?>assets/images/site_img/arrow_left.png">
				</div>
				<div class="logo cl2">
					<div align="center">
						<img src="<?= base_url(); ?>assets/images/site_img/logo.png" alt="img" align="center" />
					</div>
				</div>
				<div class="notice cl3">
					<div align="right">
						<i class="fas fa-bell"></i>
						<i class="fas fa-filter"></i>
				    </div>
				</div>
		    </div>
	    </div>
	    <div class="container">
	    	<h1>My Orders</h1>
	    		<div class="cards">
	    			<div class="row">
	    				<div class="cl5 left10">
	    					<img class="img-responsive" src="<?= base_url(); ?>assets/images/site_img/demoPic.png">
	    				</div>
	    				<div class="cl4 left20">
	    					Order No: 254<br><br>Date : 12-01-2020<br>
	    					<button class="bntmain">Check Order Status</button>
	    				</div>
	    			</div>
	    		</div>
	    		<h1>My Past Orders</h1>
	    		<div class="cards">
	    			dfgdg
	    		</div>
	    </div>
	</div>
	