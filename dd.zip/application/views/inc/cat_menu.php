<section class="cat_menu">
		<div class="container-fluid">
			<div class="cat_menu_item">
				<ul>
					<li>
						<a href="#">
							<img src="<?= base_url(); ?>assets/images/icons/fruits.png" />
							Fruits & vegitables
							<span>
								<i class="fas fa-angle-down"></i>
							</span>
					    </a>
					</li>
					<li>
						<a href="#">
							<img src="<?= base_url(); ?>assets/images/icons/grocer.png" />
							Foodgrains, Oil & Masala
							<span>
								<i class="fas fa-angle-down"></i>
							</span>
					    </a>
					</li>
					<li>
						<a href="#">
							<img src="<?= base_url(); ?>assets/images/icons/backery.png" />
							Bakery, Cakes & Dairy
							<span>
								<i class="fas fa-angle-down"></i>
							</span>
					    </a>
					</li>
					<li>
						<a href="#">
							<img src="<?= base_url(); ?>assets/images/icons/snack.png" />
							Snacks, Branded Foods
							<span>
								<i class="fas fa-angle-down"></i>
							</span>
					    </a>
					</li>
					<li>
						<a href="#">
							<img src="<?= base_url(); ?>assets/images/icons/beauty.png" />
							Beauty & Hygiene
							<span>
								<i class="fas fa-angle-down"></i>
							</span>
					    </a>
					</li>
					<li>
						<a href="#">
							<img src="<?= base_url(); ?>assets/images/icons/clean.png" />
							Cleaning & Household
							<span>
								<i class="fas fa-angle-down"></i>
							</span>
					    </a>
					</li>
					<li>
						<a href="#">
							<img src="<?= base_url(); ?>assets/images/icons/pets.png" />
							Kitchen, Garder & Pets
							<span>
								<i class="fas fa-angle-down"></i>
							</span>
					    </a>
					</li>
					<li>
						<a href="#">
							<img src="<?= base_url(); ?>assets/images/icons/egg.png" />
							Eggs, Meat & Fish
							<span>
								<i class="fas fa-angle-down"></i>
							</span>
					    </a>
					</li>
					<li>
						<a href="#">
							<img src="<?= base_url(); ?>assets/images/icons/gour.png" />
							Gourmet & World Food
							<span>
								<i class="fas fa-angle-down"></i>
							</span>
					    </a>
					</li>
					<li>
						<a href="#">
							<img src="<?= base_url(); ?>assets/images/icons/baby.png" />
							Baby Care
							<span>
								<i class="fas fa-angle-down"></i>
							</span>
					    </a>
					</li>					
				</ul>
			</div>
	    </div>
	</section>