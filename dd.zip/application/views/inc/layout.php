<meta charset="utf-8">
	<meta name = "viewport" content = "width=device-width, initial-scale=1.0">
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="<?= base_url(); ?>assets/js/font.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/style.css" />