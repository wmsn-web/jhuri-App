<?php
/**
 * 
 */
class Success extends CI_controller
{
	
	function index()
	{
		$this->load->view("success");
	}
}